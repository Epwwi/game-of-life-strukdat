# BookCatalog.py
# Mengelola dua chain Doubly Linked List yang ter-sort:
#   1. Chain by Year  : urut kronologis (ascending tahun terbit)
#   2. Chain by Title : urut alfabetikal (ascending title)
#
# Setiap buku yang ditambahkan otomatis masuk ke KEDUA chain sekaligus.
# Multi-Linked per genre juga dikelola di sini.

from BookNode import BookNode


class BookCatalog:
    def __init__(self):
        # Head & tail untuk chain by Year
        self.headByYear  = None
        self.tailByYear  = None

        # Head & tail untuk chain by Title
        self.headByTitle = None
        self.tailByTitle = None

        # Multi-linked: head node per genre
        # key   = nama genre
        # value = BookNode pertama dalam chain genre tersebut
        self.genreHeads: dict = {}

        self.total_books = 0

    # ------------------------------------------------------------------ #
    #  INSERT                                                              #
    # ------------------------------------------------------------------ #
    def add_book(self, title: str, author: str, year: int, synopsis: str,
                 genres: list = None, stock: int = 1) -> BookNode:
        """Tambahkan buku baru ke katalog dan masukkan ke semua chain."""
        node = BookNode(title, author, year, synopsis, genres, stock)
        self._insert_by_year(node)
        self._insert_by_title(node)
        for genre in node.genres:
            self._insert_by_genre(node, genre)
        self.total_books += 1
        return node

    def _insert_by_year(self, new_node: BookNode):
        """Insert ke chain Year (sorted ascending by year)."""
        if self.headByYear is None:
            self.headByYear = self.tailByYear = new_node
            return

        if new_node.year <= self.headByYear.year:
            new_node.nextByYear        = self.headByYear
            self.headByYear.prevByYear = new_node
            self.headByYear            = new_node
            return

        if new_node.year >= self.tailByYear.year:
            new_node.prevByYear        = self.tailByYear
            self.tailByYear.nextByYear = new_node
            self.tailByYear            = new_node
            return

        cur = self.headByYear
        while cur is not None and cur.year < new_node.year:
            cur = cur.nextByYear

        prev_node              = cur.prevByYear
        new_node.nextByYear    = cur
        new_node.prevByYear    = prev_node
        prev_node.nextByYear   = new_node
        cur.prevByYear         = new_node

    def _insert_by_title(self, new_node: BookNode):
        """Insert ke chain Title (sorted ascending alphabetically)."""
        if self.headByTitle is None:
            self.headByTitle = self.tailByTitle = new_node
            return

        if new_node.title.lower() <= self.headByTitle.title.lower():
            new_node.nextByTitle         = self.headByTitle
            self.headByTitle.prevByTitle = new_node
            self.headByTitle             = new_node
            return

        if new_node.title.lower() >= self.tailByTitle.title.lower():
            new_node.prevByTitle         = self.tailByTitle
            self.tailByTitle.nextByTitle = new_node
            self.tailByTitle             = new_node
            return

        cur = self.headByTitle
        while cur is not None and cur.title.lower() < new_node.title.lower():
            cur = cur.nextByTitle

        prev_node                  = cur.prevByTitle
        new_node.nextByTitle       = cur
        new_node.prevByTitle       = prev_node
        prev_node.nextByTitle      = new_node
        cur.prevByTitle            = new_node

    def _insert_by_genre(self, new_node: BookNode, genre: str):
        """Insert node ke chain genre tertentu (singly, prepend)."""
        if genre not in self.genreHeads:
            self.genreHeads[genre] = new_node
        else:
            new_node.genreLinks[genre]  = self.genreHeads[genre]
            self.genreHeads[genre]      = new_node

    # ------------------------------------------------------------------ #
    #  BORROW & RETURN                                                     #
    # ------------------------------------------------------------------ #
    def borrow_book(self, title: str) -> bool:
        """Pinjam buku berdasarkan judul. Return True jika berhasil."""
        node = self._find_by_title(title)
        if node is None:
            print(f"  ❌ Buku '{title}' tidak ditemukan.")
            return False
        if not node.is_available():
            print(f"  ❌ Buku '{title}' sedang habis dipinjam (stok: {node.stock}, dipinjam: {node.borrowed}).")
            return False
        node.borrowed += 1
        print(f"  ✅ Berhasil meminjam '{title}'. Sisa tersedia: {node.available_count()}")
        return True

    def return_book(self, title: str) -> bool:
        """Kembalikan buku berdasarkan judul. Return True jika berhasil."""
        node = self._find_by_title(title)
        if node is None:
            print(f"  ❌ Buku '{title}' tidak ditemukan.")
            return False
        if node.borrowed == 0:
            print(f"  ❌ Tidak ada peminjaman aktif untuk '{title}'.")
            return False
        node.borrowed -= 1
        print(f"  ✅ Berhasil mengembalikan '{title}'. Tersedia: {node.available_count()}")
        return True

    def _find_by_title(self, title: str):
        """Cari node buku berdasarkan judul (exact match, case-insensitive)."""
        cur = self.headByTitle
        while cur is not None:
            if cur.title.lower() == title.lower():
                return cur
            cur = cur.nextByTitle
        return None

    # ------------------------------------------------------------------ #
    #  VIEW                                                                #
    # ------------------------------------------------------------------ #
    def view_by_year(self, reverse: bool = False):
        """Tampilkan semua buku urut tahun terbit."""
        label = " (Terbaru → Terlama)" if reverse else " (Terlama → Terbaru)"
        print(f"\n📅 KATALOG URUT TAHUN TERBIT{label}")
        print("=" * 60)
        if reverse:
            cur = self.tailByYear
            while cur is not None:
                self._print_book(cur)
                cur = cur.prevByYear
        else:
            cur = self.headByYear
            while cur is not None:
                self._print_book(cur)
                cur = cur.nextByYear

    def view_by_title(self, reverse: bool = False):
        """Tampilkan semua buku urut alfabetikal judul."""
        label = " (Z → A)" if reverse else " (A → Z)"
        print(f"\n🔤 KATALOG URUT JUDUL{label}")
        print("=" * 60)
        if reverse:
            cur = self.tailByTitle
            while cur is not None:
                self._print_book(cur)
                cur = cur.prevByTitle
        else:
            cur = self.headByTitle
            while cur is not None:
                self._print_book(cur)
                cur = cur.nextByTitle

    def view_by_genre(self, genre: str):
        """Tampilkan semua buku dalam genre tertentu."""
        print(f"\n📚 BUKU GENRE: '{genre.upper()}'")
        print("=" * 60)
        if genre not in self.genreHeads:
            print(f"  (Tidak ada buku dengan genre '{genre}')")
            return
        cur = self.genreHeads[genre]
        while cur is not None:
            self._print_book(cur)
            cur = cur.genreLinks.get(genre)

    def view_available_only(self):
        """Tampilkan hanya buku yang masih tersedia untuk dipinjam."""
        print("\n✅ BUKU YANG TERSEDIA")
        print("=" * 60)
        found = False
        cur = self.headByTitle
        while cur is not None:
            if cur.is_available():
                self._print_book(cur)
                found = True
            cur = cur.nextByTitle
        if not found:
            print("  (Semua buku sedang dipinjam)")

    # ------------------------------------------------------------------ #
    #  SEARCH                                                              #
    # ------------------------------------------------------------------ #
    def search_by_title(self, keyword: str):
        """Cari buku berdasarkan keyword di judul (case-insensitive)."""
        print(f"\n🔍 CARI JUDUL: '{keyword}'")
        print("=" * 60)
        found = False
        cur = self.headByTitle
        while cur is not None:
            if keyword.lower() in cur.title.lower():
                self._print_book(cur)
                found = True
            cur = cur.nextByTitle
        if not found:
            print("  (Tidak ditemukan)")

    def search_by_author(self, keyword: str):
        """Cari buku berdasarkan keyword nama pengarang (case-insensitive)."""
        print(f"\n🔍 CARI PENGARANG: '{keyword}'")
        print("=" * 60)
        found = False
        cur = self.headByTitle
        while cur is not None:
            if keyword.lower() in cur.author.lower():
                self._print_book(cur)
                found = True
            cur = cur.nextByTitle
        if not found:
            print("  (Tidak ditemukan)")

    # ------------------------------------------------------------------ #
    #  STATISTICS                                                          #
    # ------------------------------------------------------------------ #
    def show_stats(self):
        """Tampilkan statistik koleksi perpustakaan."""
        total_stock    = 0
        total_borrowed = 0
        cur = self.headByTitle
        while cur is not None:
            total_stock    += cur.stock
            total_borrowed += cur.borrowed
            cur = cur.nextByTitle

        print("\n📊 STATISTIK PERPUSTAKAAN")
        print("=" * 60)
        print(f"  Total judul buku  : {self.total_books}")
        print(f"  Total eksemplar   : {total_stock}")
        print(f"  Sedang dipinjam   : {total_borrowed}")
        print(f"  Tersedia          : {total_stock - total_borrowed}")
        print(f"  Genre terdaftar   : {list(self.genreHeads.keys())}")

    # ------------------------------------------------------------------ #
    #  HELPER                                                              #
    # ------------------------------------------------------------------ #
    def _print_book(self, node: BookNode):
        status = f"✅ {node.available_count()} tersedia" if node.is_available() else "❌ Habis dipinjam"
        print(f"  📖 {node.title} ({node.year})")
        print(f"     Pengarang : {node.author}")
        print(f"     Genre     : {node.genres}")
        print(f"     Stok      : {status} (total: {node.stock})")
        print(f"     Sinopsis  : {node.synopsis[:65]}{'...' if len(node.synopsis) > 65 else ''}")
        print()
