# BookNode.py
# Definisi struktur node untuk aplikasi manajemen buku perpustakaan
# Menggunakan konsep Multi-Linked List:
#   - nextByYear / prevByYear     : chain doubly linked, urut berdasarkan tahun terbit
#   - nextByTitle / prevByTitle   : chain doubly linked, urut berdasarkan judul (alfabetikal)
#   - genreLinks                  : dict of next pointers per genre (multi-linked per genre)


class BookNode:
    def __init__(self, title: str, author: str, year: int, synopsis: str, genres: list = None, stock: int = 1):
        """
        Parameter:
            title    : judul buku
            author   : nama pengarang
            year     : tahun terbit
            synopsis : ringkasan buku
            genres   : list genre (misal: ['fiksi', 'petualangan'])
            stock    : jumlah stok tersedia
        """
        self.title    = title
        self.author   = author
        self.year     = year
        self.synopsis = synopsis
        self.genres   = genres if genres is not None else []
        self.stock    = stock
        self.borrowed = 0  # jumlah yang sedang dipinjam

        # --- Doubly Linked: chain by Year ---
        self.nextByYear = None
        self.prevByYear = None

        # --- Doubly Linked: chain by Title (alfabetikal) ---
        self.nextByTitle = None
        self.prevByTitle = None

        # --- Multi-Linked: satu pointer per genre ---
        # key   = nama genre (string)
        # value = BookNode berikutnya dalam chain genre tersebut
        self.genreLinks: dict = {g: None for g in self.genres}

    def add_genre(self, genre: str):
        """Tambah genre baru ke buku ini (jika belum ada)."""
        if genre not in self.genres:
            self.genres.append(genre)
            self.genreLinks[genre] = None

    def is_available(self) -> bool:
        """Cek apakah buku masih tersedia untuk dipinjam."""
        return (self.stock - self.borrowed) > 0

    def available_count(self) -> int:
        """Jumlah eksemplar yang tersedia."""
        return self.stock - self.borrowed

    def __repr__(self):
        return (f"BookNode(title='{self.title}', "
                f"author='{self.author}', "
                f"year={self.year}, "
                f"genres={self.genres}, "
                f"stock={self.stock})")
