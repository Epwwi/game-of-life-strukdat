# ActivityLog.py
# Circular Linked List sebagai log aktivitas perpustakaan
#
# Cara kerja:
#   - Log menyimpan maksimal `capacity` aktivitas terakhir
#   - Ketika penuh, entri terlama otomatis ditimpa (circular overwrite)
#   - listRef menunjuk ke node TERAKHIR yang dimasukkan (tail circular)
#
# Aktivitas yang dicatat: 'BORROW', 'RETURN', 'ADD', 'REMOVE'

from datetime import datetime


class ActivityNode:
    """Node untuk circular activity log."""
    def __init__(self, book_title: str, action: str, member_name: str = "Sistem",
                 timestamp: datetime = None):
        self.book_title  = book_title
        self.action      = action          # 'BORROW', 'RETURN', 'ADD', 'REMOVE'
        self.member_name = member_name     # nama anggota yang melakukan aksi
        self.timestamp   = timestamp if timestamp is not None else datetime.now()
        self.verified    = False           # sudah diverifikasi petugas?
        self.next        = None

    def __repr__(self):
        status = "✔ verified" if self.verified else "○ unverified"
        return (f"[{self.timestamp.strftime('%Y-%m-%d %H:%M')}] "
                f"{self.action:6} | '{self.book_title}' | "
                f"oleh: {self.member_name} | {status}")


class ActivityLog:
    """
    Circular Linked List Log untuk mencatat N aktivitas terbaru.
    listRef → node terakhir dimasukkan (tail circular).
    listRef.next → node pertama/tertua dalam log.
    """

    def __init__(self, capacity: int = 7):
        self.capacity = capacity
        self.listRef  = None   # menunjuk ke node TERAKHIR
        self.size     = 0

    # ------------------------------------------------------------------ #
    #  RECORD ACTIVITY                                                     #
    # ------------------------------------------------------------------ #
    def record(self, book_title: str, action: str, member_name: str = "Sistem",
               timestamp: datetime = None):
        """
        Catat aktivitas baru ke circular log.
        Jika sudah penuh, aktivitas terlama ditimpa otomatis.
        """
        new_node = ActivityNode(book_title, action, member_name, timestamp)

        if self.listRef is None:
            # Log kosong → node menunjuk ke dirinya sendiri
            new_node.next = new_node
            self.listRef  = new_node
            self.size     = 1
        elif self.size < self.capacity:
            # Masih ada ruang → insert setelah listRef (sebelum first)
            new_node.next      = self.listRef.next   # new → oldest
            self.listRef.next  = new_node             # last → new
            self.listRef       = new_node             # update tail
            self.size         += 1
        else:
            # Log penuh → timpa node tertua (listRef.next = oldest)
            oldest            = self.listRef.next
            new_node.next     = oldest.next
            self.listRef.next = new_node
            self.listRef      = new_node

    # ------------------------------------------------------------------ #
    #  VERIFY                                                              #
    # ------------------------------------------------------------------ #
    def verify_all(self):
        """Verifikasi semua aktivitas dalam log."""
        if self.listRef is None:
            return
        cur  = self.listRef
        done = False
        while not done:
            cur          = cur.next
            cur.verified = True
            done         = (cur is self.listRef)

    def verify_by_member(self, member_name: str):
        """Verifikasi semua aktivitas dari anggota tertentu."""
        if self.listRef is None:
            return
        cur  = self.listRef
        done = False
        while not done:
            cur = cur.next
            if cur.member_name.lower() == member_name.lower():
                cur.verified = True
            done = (cur is self.listRef)

    # ------------------------------------------------------------------ #
    #  VIEW                                                                #
    # ------------------------------------------------------------------ #
    def view_log(self):
        """Tampilkan semua aktivitas dalam log (tertua → terbaru)."""
        print("\n📋 LOG AKTIVITAS PERPUSTAKAAN")
        print(f"   Kapasitas: {self.size}/{self.capacity} slot terisi")
        print("=" * 65)
        if self.listRef is None:
            print("  (Log kosong)")
            return

        # Traversal dari oldest (listRef.next) sampai newest (listRef)
        cur  = self.listRef
        done = False
        while not done:
            cur = cur.next
            print(f"  {cur}")
            done = (cur is self.listRef)

    def view_unverified(self):
        """Tampilkan hanya aktivitas yang belum diverifikasi."""
        print("\n⚠️  AKTIVITAS BELUM DIVERIFIKASI")
        print("=" * 65)
        if self.listRef is None:
            print("  (Log kosong)")
            return

        cur    = self.listRef
        done   = False
        found  = False
        while not done:
            cur  = cur.next
            if not cur.verified:
                print(f"  {cur}")
                found = True
            done = (cur is self.listRef)

        if not found:
            print("  (Semua aktivitas sudah diverifikasi)")

    def count_by_action(self, action: str) -> int:
        """Hitung jumlah aktivitas dengan jenis tertentu dalam log."""
        if self.listRef is None:
            return 0
        count = 0
        cur   = self.listRef
        done  = False
        while not done:
            cur = cur.next
            if cur.action == action:
                count += 1
            done = (cur is self.listRef)
        return count

    def get_unverified_count(self) -> int:
        """Hitung jumlah aktivitas yang belum diverifikasi."""
        if self.listRef is None:
            return 0
        count = 0
        cur   = self.listRef
        done  = False
        while not done:
            cur = cur.next
            if not cur.verified:
                count += 1
            done = (cur is self.listRef)
        return count
