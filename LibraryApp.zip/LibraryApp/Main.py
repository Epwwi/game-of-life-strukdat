# Main.py
# Entry point & demonstrasi lengkap struktur data Library Management App
#
# Struktur data yang digunakan (Advanced Linked Lists):
#   1. Multi-Linked List  → multiple genres per buku
#   2. Doubly Linked List → urut tahun terbit & urut judul alfabetikal
#   3. Circular Log       → riwayat aktivitas perpustakaan (N terbaru)

from datetime import datetime
from BookCatalog import BookCatalog
from ActivityLog  import ActivityLog


def separator(label: str = ""):
    print("\n" + "=" * 60)
    if label:
        print(f"  {label}")
        print("=" * 60)


def main():
    separator("📚 LIBRARY MANAGEMENT — Advanced Linked Lists Demo")

    catalog = BookCatalog()
    log     = ActivityLog(capacity=7)

    # ------------------------------------------------------------------ #
    #  1. TAMBAH KOLEKSI BUKU                                             #
    # ------------------------------------------------------------------ #
    separator("➕ MENAMBAHKAN KOLEKSI BUKU")

    books_data = [
        ("Laskar Pelangi",
         "Andrea Hirata",
         2005,
         "Kisah sepuluh anak Belitung yang berjuang mengejar mimpi di sekolah sederhana.",
         ["fiksi", "inspirasi", "lokal"],
         3),

        ("Dune",
         "Frank Herbert",
         1965,
         "Epik fiksi ilmiah tentang planet gurun Arrakis dan perebutan rempah terlangka semesta.",
         ["fiksi", "sci-fi", "petualangan"],
         2),

        ("Sapiens",
         "Yuval Noah Harari",
         2011,
         "Sejarah singkat umat manusia dari zaman batu hingga era digital.",
         ["non-fiksi", "sejarah", "sains"],
         4),

        ("Bumi Manusia",
         "Pramoedya Ananta Toer",
         1980,
         "Kisah Minke, pemuda pribumi yang tumbuh di tengah kolonialisme Belanda.",
         ["fiksi", "sejarah", "lokal"],
         2),

        ("The Pragmatic Programmer",
         "Andrew Hunt & David Thomas",
         1999,
         "Panduan praktis menjadi programmer handal, penuh tips dan filosofi pemrograman.",
         ["non-fiksi", "teknologi", "programming"],
         3),

        ("Cosmos",
         "Carl Sagan",
         1980,
         "Perjalanan puitis dan ilmiah mengelilingi alam semesta bersama Carl Sagan.",
         ["non-fiksi", "sains", "astronomi"],
         2),

        ("Negeri 5 Menara",
         "Ahmad Fuadi",
         2009,
         "Perjalanan enam santri dari pesantren menggapai mimpi keliling dunia.",
         ["fiksi", "inspirasi", "lokal"],
         3),

        ("Clean Code",
         "Robert C. Martin",
         2008,
         "Panduan menulis kode bersih dan terpelihara, wajib baca setiap programmer.",
         ["non-fiksi", "teknologi", "programming"],
         2),
    ]

    for title, author, year, synopsis, genres, stock in books_data:
        catalog.add_book(title, author, year, synopsis, genres, stock)
        log.record(title, "ADD", "Sistem", datetime(year, 1, 1))
        print(f"  ✅ Ditambahkan: '{title}' ({year}) | Genre: {genres} | Stok: {stock}")

    # ------------------------------------------------------------------ #
    #  2. VIEW URUT TAHUN TERBIT                                          #
    # ------------------------------------------------------------------ #
    catalog.view_by_year()              # terlama → terbaru
    catalog.view_by_year(reverse=True)  # terbaru → terlama

    # ------------------------------------------------------------------ #
    #  3. VIEW URUT JUDUL ALFABETIKAL                                     #
    # ------------------------------------------------------------------ #
    catalog.view_by_title()             # A → Z
    catalog.view_by_title(reverse=True) # Z → A

    # ------------------------------------------------------------------ #
    #  4. VIEW BERDASARKAN GENRE (Multi-Linked)                           #
    # ------------------------------------------------------------------ #
    catalog.view_by_genre("fiksi")
    catalog.view_by_genre("programming")
    catalog.view_by_genre("sains")

    # ------------------------------------------------------------------ #
    #  5. SEARCH                                                           #
    # ------------------------------------------------------------------ #
    catalog.search_by_title("man")
    catalog.search_by_author("harari")
    catalog.search_by_title("xyz_tidak_ada")

    # ------------------------------------------------------------------ #
    #  6. SIMULASI PEMINJAMAN & PENGEMBALIAN                              #
    # ------------------------------------------------------------------ #
    separator("📤 SIMULASI PEMINJAMAN BUKU")

    borrow_events = [
        ("Laskar Pelangi", "Andi",      datetime(2025, 6, 1, 9, 0)),
        ("Laskar Pelangi", "Budi",      datetime(2025, 6, 2, 10, 0)),
        ("Laskar Pelangi", "Citra",     datetime(2025, 6, 3, 11, 0)),
        ("Dune",           "Dewi",      datetime(2025, 6, 3, 13, 0)),
        ("Sapiens",        "Erik",      datetime(2025, 6, 4, 14, 0)),
        ("Clean Code",     "Fajar",     datetime(2025, 6, 5, 8, 0)),
    ]

    for title, member, ts in borrow_events:
        print(f"\n  👤 {member} meminjam '{title}'...")
        success = catalog.borrow_book(title)
        if success:
            log.record(title, "BORROW", member, ts)

    # Percobaan pinjam buku yang habis
    print(f"\n  👤 Gilang mencoba meminjam 'Laskar Pelangi' (seharusnya gagal)...")
    catalog.borrow_book("Laskar Pelangi")

    # View buku yang tersedia setelah peminjaman
    catalog.view_available_only()

    # ------------------------------------------------------------------ #
    #  7. SIMULASI PENGEMBALIAN                                           #
    # ------------------------------------------------------------------ #
    separator("📥 SIMULASI PENGEMBALIAN BUKU")

    return_events = [
        ("Laskar Pelangi", "Budi",      datetime(2025, 6, 10, 9, 0)),
        ("Dune",           "Dewi",      datetime(2025, 6, 11, 15, 0)),
    ]

    for title, member, ts in return_events:
        print(f"\n  👤 {member} mengembalikan '{title}'...")
        success = catalog.return_book(title)
        if success:
            log.record(title, "RETURN", member, ts)

    # Percobaan kembalikan buku yang tidak sedang dipinjam
    print(f"\n  👤 Hendra mencoba mengembalikan 'Cosmos' (tidak pernah dipinjam)...")
    catalog.return_book("Cosmos")

    # ------------------------------------------------------------------ #
    #  8. ACTIVITY LOG — Circular Linked List                            #
    # ------------------------------------------------------------------ #
    log.view_log()
    print(f"\n  ○ Aktivitas belum diverifikasi : {log.get_unverified_count()}")
    print(f"  📤 Total BORROW dalam log      : {log.count_by_action('BORROW')}")
    print(f"  📥 Total RETURN dalam log      : {log.count_by_action('RETURN')}")

    # Verifikasi aktivitas anggota tertentu
    print("\n🔁 Verifikasi aktivitas milik 'Andi'...")
    log.verify_by_member("Andi")
    log.view_unverified()

    # Verifikasi semua
    print("\n🔁 Verifikasi semua aktivitas...")
    log.verify_all()
    print(f"  ✅ Aktivitas belum diverifikasi: {log.get_unverified_count()}")

    # ------------------------------------------------------------------ #
    #  9. STATISTIK AKHIR                                                 #
    # ------------------------------------------------------------------ #
    catalog.show_stats()

    separator("✅ DEMO SELESAI")
    print(f"  Total judul terdaftar : {catalog.total_books}")
    print(f"  Slot log digunakan    : {log.size}/{log.capacity}")
    print("=" * 60)


if __name__ == "__main__":
    main()
